A Pen created at CodePen.io. You can find this one at http://codepen.io/jamesacklin/pen/eEKIJ.

 A nice green and yellow login form.